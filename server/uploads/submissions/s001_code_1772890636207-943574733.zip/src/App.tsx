import React, { useEffect, useState } from 'react';
import { Search, HelpCircle, Download, Spade, X, TrendingUp, Building, Users, ShieldCheck, Loader2, Activity } from 'lucide-react';
import Markdown from 'react-markdown';
import { GoogleGenAI } from '@google/genai';

export default function App() {
  const [portfolio, setPortfolio] = useState<any[]>([]);
  const [predictions, setPredictions] = useState<any[]>([]);
  const [newStock, setNewStock] = useState({ code: '', name: '', cost: '', quantity: '' });
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('portfolio'); // 'portfolio' or 'predictions'

  // AI Consultation State
  const [consultingStock, setConsultingStock] = useState<any>(null);
  const [isConsulting, setIsConsulting] = useState(false);
  const [streams, setStreams] = useState({ tech: '', fund: '', sent: '', chief: '' });

  const fetchPortfolio = async () => {
    try {
      const res = await fetch('/api/v1/portfolio');
      const data = await res.json();
      
      // Fetch real-time prices for portfolio
      const updatedPortfolio = await Promise.all(
        data.map(async (stock: any) => {
          try {
            const quoteRes = await fetch(`/api/v1/stock/${stock.code}/realtime`);
            if (quoteRes.ok) {
              const quote = await quoteRes.json();
              return { ...stock, currentPrice: quote.price, changePercent: quote.changePercent };
            }
          } catch (e) {
            console.error('Error fetching quote for', stock.code);
          }
          return { ...stock, currentPrice: 0, changePercent: 0 };
        })
      );
      
      setPortfolio(updatedPortfolio);
    } catch (error) {
      console.error('Failed to fetch portfolio', error);
    }
  };

  const fetchPredictions = async () => {
    try {
      const res = await fetch('/api/v1/predictions');
      const data = await res.json();
      setPredictions(data);
    } catch (error) {
      console.error('Failed to fetch predictions', error);
    }
  };

  const verifyPredictions = async () => {
    try {
      await fetch('/api/v1/predictions/verify', { method: 'POST' });
      fetchPredictions();
    } catch (error) {
      console.error('Failed to verify predictions', error);
    }
  };

  useEffect(() => {
    fetchPortfolio();
    fetchPredictions();
    const interval = setInterval(() => {
      fetchPortfolio();
      verifyPredictions();
    }, 10000); // Poll every 10s
    return () => clearInterval(interval);
  }, []);

  const handleAddStock = async () => {
    if (!newStock.code) return;
    setLoading(true);
    try {
      // Try to fetch name if not provided
      let name = newStock.name;
      if (!name) {
        const quoteRes = await fetch(`/api/v1/stock/${newStock.code}/realtime`);
        if (quoteRes.ok) {
          const quote = await quoteRes.json();
          name = quote.name || newStock.code;
        }
      }

      await fetch('/api/v1/portfolio/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: newStock.code,
          name: name || newStock.code,
          cost_price: parseFloat(newStock.cost) || 0,
          quantity: parseInt(newStock.quantity) || 0,
        }),
      });
      setNewStock({ code: '', name: '', cost: '', quantity: '' });
      fetchPortfolio();
    } catch (error) {
      console.error('Failed to add stock', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await fetch(`/api/v1/portfolio/${id}`, { method: 'DELETE' });
      fetchPortfolio();
    } catch (error) {
      console.error('Failed to delete stock', error);
    }
  };

  const startConsultation = async (stock: any) => {
    setConsultingStock(stock);
    setStreams({ tech: '', fund: '', sent: '', chief: '' });
    setIsConsulting(true);

    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    const model = 'gemini-3-flash-preview';
    const basePrompt = `请分析股票：${stock.name} (${stock.code})，当前价格：${stock.currentPrice}。`;

    const runAgent = async (agentId: string, role: string, prompt: string) => {
      try {
        const responseStream = await ai.models.generateContentStream({
          model,
          contents: prompt,
          config: { systemInstruction: role }
        });
        let fullText = '';
        for await (const chunk of responseStream) {
          const text = chunk.text || '';
          fullText += text;
          setStreams(prev => ({ ...prev, [agentId]: prev[agentId] + text }));
        }
        return fullText;
      } catch (error) {
        console.error(`Error in agent ${agentId}:`, error);
        setStreams(prev => ({ ...prev, [agentId]: prev[agentId] + '\n[分析失败]' }));
        return '分析失败';
      }
    };

    try {
      // Run 3 agents concurrently
      const [tech, fund, sent] = await Promise.all([
        runAgent('tech', '你是一个资深技术面分析师。请根据当前价格和代码，简要分析其技术面走势可能的情况（假设性分析）。', basePrompt),
        runAgent('fund', '你是一个资深基本面分析师。请简要分析该股票所属行业的基本面情况及估值逻辑。', basePrompt),
        runAgent('sent', '你是一个市场情绪分析师。请简要分析当前市场对该股票或其板块的情绪和资金博弈情况。', basePrompt)
      ]);

      // Run Chief
      const chiefPrompt = `
        股票：${stock.name} (${stock.code})，当前价格：${stock.currentPrice}。
        以下是三位分析师的观点：
        【技术面】：${tech}
        【基本面】：${fund}
        【情绪面】：${sent}
        请作为首席风控官，综合以上观点，给出一份最终的共识/分歧总结，并给出明确的操作建议（看涨/看跌/持有）和目标价预测。
        请在最后一行以 JSON 格式输出你的核心结论，格式如下：
        {"recommendation": "看涨", "target_price": 100.5}
      `;

      const chiefResult = await runAgent('chief', '你是一个首席风控官。你需要综合多方意见，给出最终的投资决策。', chiefPrompt);
      
      // Parse chief result to extract recommendation and target price
      let recommendation = '持有';
      let targetPrice = null;
      try {
        const jsonMatch = chiefResult.match(/\{.*\}/s);
        if (jsonMatch) {
          const parsed = JSON.parse(jsonMatch[0]);
          if (parsed.recommendation) recommendation = parsed.recommendation;
          if (parsed.target_price) targetPrice = parsed.target_price;
        } else {
          if (chiefResult.includes('看涨')) recommendation = '看涨';
          else if (chiefResult.includes('看跌')) recommendation = '看跌';
        }
      } catch (e) {
        console.error('Failed to parse chief JSON', e);
      }

      // Save prediction to DB
      await fetch('/api/v1/predictions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: stock.code,
          name: stock.name,
          price_at_prediction: stock.currentPrice,
          recommendation,
          target_price: targetPrice,
          chief_summary: chiefResult
        })
      });
      
      fetchPredictions();
      setIsConsulting(false);
    } catch (error) {
      console.error('Consultation error:', error);
      setIsConsulting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f5f6f8] font-sans text-gray-800">
      {/* Navbar */}
      <nav className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-8">
          <div className="flex items-center gap-2 text-[#e60012] font-bold text-xl tracking-tight">
            <Spade className="fill-current w-6 h-6" />
            <span>同花顺风格工作站</span>
          </div>
          <div className="flex gap-6 text-gray-700 font-medium text-[15px]">
            <a href="#" className="text-[#e60012] border-b-2 border-[#e60012] pb-1 font-bold">A股</a>
            <a href="#" className="hover:text-[#e60012] pb-1 transition-colors">港股</a>
            <a href="#" className="hover:text-[#e60012] pb-1 transition-colors">美股</a>
            <a href="#" className="hover:text-[#e60012] pb-1 transition-colors">期货</a>
            <a href="#" className="hover:text-[#e60012] pb-1 transition-colors">基金</a>
          </div>
        </div>
        <div className="flex items-center gap-5">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input 
              type="text" 
              placeholder="搜索大盘、股票、公告..." 
              className="pl-9 pr-4 py-1.5 bg-gray-50 border border-gray-200 rounded text-sm focus:outline-none focus:border-red-400 focus:bg-white transition-colors w-64" 
            />
          </div>
          <a href="#" className="text-gray-600 text-sm flex items-center gap-1 hover:text-[#e60012] transition-colors">
            <HelpCircle className="w-4 h-4"/> 问财
          </a>
          <a href="#" className="text-gray-600 text-sm hover:text-[#e60012] transition-colors">返回旧版</a>
          <a href="#" className="text-gray-600 text-sm flex items-center gap-1 border border-gray-300 px-3 py-1.5 rounded hover:text-[#e60012] hover:border-[#e60012] transition-colors">
            <Download className="w-4 h-4"/> 下载客户端
          </a>
          <button className="text-[#e60012] border border-[#e60012] px-5 py-1.5 rounded hover:bg-red-50 transition-colors font-medium">
            登录
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-[1400px] mx-auto p-4 grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-4 mt-2">
        
        {/* Left Column */}
        <div className="space-y-4">
          
          {/* Real-time Portfolio Overview */}
          <div className="bg-white p-5 shadow-sm border border-gray-200 rounded-sm min-h-[140px]">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-gray-800 font-bold text-[16px] flex items-center gap-2">
                <Activity className="w-5 h-5 text-[#e60012]" />
                自选股实时速览
              </h2>
              <span className="text-xs text-gray-400">点击卡片快速发起 AI 会诊</span>
            </div>
            
            {portfolio.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                {portfolio.map(stock => {
                  const isUp = stock.changePercent >= 0;
                  const colorClass = isUp ? 'text-[#e60012]' : 'text-[#00a800]';
                  const bgColorClass = isUp ? 'bg-red-50/30 border-red-100 hover:border-red-300' : 'bg-green-50/30 border-green-100 hover:border-green-300';
                  
                  return (
                    <div 
                      key={stock.id} 
                      className={`p-4 rounded border ${bgColorClass} flex flex-col cursor-pointer transition-all hover:shadow-sm group`} 
                      onClick={() => startConsultation(stock)}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <span className="text-gray-800 font-bold text-[15px] truncate pr-2 group-hover:text-[#e60012] transition-colors">{stock.name}</span>
                        <span className="text-gray-400 text-xs font-mono">{stock.code}</span>
                      </div>
                      <div className="flex items-baseline gap-2 mt-1">
                        <span className={`text-2xl font-bold ${colorClass}`}>
                          {stock.currentPrice ? stock.currentPrice.toFixed(2) : '--'}
                        </span>
                      </div>
                      <div className="mt-1">
                        <span className={`text-sm font-medium ${colorClass}`}>
                          {stock.changePercent ? (stock.changePercent > 0 ? '+' : '') + (stock.changePercent * 100).toFixed(2) + '%' : '--'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center text-gray-400 py-6">
                <Search className="w-8 h-8 mb-2 opacity-30" />
                <span className="text-sm">暂无自选股，请在下方添加</span>
              </div>
            )}
          </div>

          {/* Main Content Area with Tabs */}
          <div className="bg-white shadow-sm border border-gray-200 rounded-sm flex flex-col min-h-[450px]">
            <div className="flex justify-between items-center border-b border-gray-200 px-5 pt-3 pb-0">
              <div className="flex gap-6">
                <button 
                  onClick={() => setActiveTab('portfolio')}
                  className={`font-bold text-[15px] pb-2 px-1 -mb-[1.5px] transition-colors ${activeTab === 'portfolio' ? 'text-[#e60012] border-b-[3px] border-[#e60012]' : 'text-gray-500 hover:text-gray-800'}`}
                >
                  自选股池
                </button>
                <button 
                  onClick={() => setActiveTab('predictions')}
                  className={`font-bold text-[15px] pb-2 px-1 -mb-[1.5px] transition-colors flex items-center gap-1 ${activeTab === 'predictions' ? 'text-[#e60012] border-b-[3px] border-[#e60012]' : 'text-gray-500 hover:text-gray-800'}`}
                >
                  <ShieldCheck className="w-4 h-4" /> AI“打脸”回测系统
                </button>
              </div>
              
              {activeTab === 'portfolio' && (
                <div className="flex items-center gap-0 text-sm mb-2">
                  <div className="relative">
                    <Search className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-400 w-3.5 h-3.5" />
                    <input 
                      type="text" 
                      placeholder="代码/拼音" 
                      value={newStock.code}
                      onChange={e => setNewStock({...newStock, code: e.target.value})}
                      className="pl-7 pr-2 py-1.5 border border-gray-300 rounded-l w-28 focus:outline-none focus:border-gray-400 bg-gray-50/50" 
                    />
                  </div>
                  <input 
                    type="text" 
                    placeholder="名称" 
                    value={newStock.name}
                    onChange={e => setNewStock({...newStock, name: e.target.value})}
                    className="px-2 py-1.5 border-y border-r border-gray-300 w-20 focus:outline-none focus:border-gray-400 bg-gray-50/50" 
                  />
                  <input 
                    type="text" 
                    placeholder="成本" 
                    value={newStock.cost}
                    onChange={e => setNewStock({...newStock, cost: e.target.value})}
                    className="px-2 py-1.5 border-y border-r border-gray-300 w-20 focus:outline-none focus:border-gray-400 bg-gray-50/50" 
                  />
                  <input 
                    type="text" 
                    placeholder="数量" 
                    value={newStock.quantity}
                    onChange={e => setNewStock({...newStock, quantity: e.target.value})}
                    className="px-2 py-1.5 border-y border-r border-gray-300 w-20 focus:outline-none focus:border-gray-400 bg-gray-50/50" 
                  />
                  <button 
                    onClick={handleAddStock}
                    disabled={loading || !newStock.code}
                    className="bg-[#e60012] text-white px-5 py-1.5 rounded-r hover:bg-red-700 transition-colors disabled:opacity-50 font-medium"
                  >
                    加入
                  </button>
                </div>
              )}
            </div>
            
            {activeTab === 'portfolio' ? (
              <table className="w-full text-sm text-center">
                <thead className="bg-[#f8f9fa] text-gray-500 border-b border-gray-200 text-[13px]">
                  <tr>
                    <th className="py-3 font-normal w-[15%]">代码</th>
                    <th className="py-3 font-normal w-[20%]">名称</th>
                    <th className="py-3 font-normal w-[15%]">最新价</th>
                    <th className="py-3 font-normal w-[15%]">涨跌幅</th>
                    <th className="py-3 font-normal w-[15%]">持仓成本</th>
                    <th className="py-3 font-normal w-[10%]">盈亏金额</th>
                    <th className="py-3 font-normal w-[10%]">特别操作</th>
                  </tr>
                </thead>
                <tbody>
                  {portfolio.map((stock) => {
                    const currentPrice = stock.currentPrice || 0;
                    const changePercent = stock.changePercent || 0;
                    const isUp = changePercent > 0;
                    const isDown = changePercent < 0;
                    const colorClass = isUp ? 'text-[#e60012]' : isDown ? 'text-[#00a800]' : 'text-gray-800';
                    const bgClass = isUp ? 'bg-[#e60012] text-white' : isDown ? 'bg-[#00a800] text-white' : 'bg-gray-200 text-gray-800';
                    
                    const pnl = (currentPrice - stock.cost_price) * stock.quantity;
                    const pnlColor = pnl > 0 ? 'text-[#e60012]' : pnl < 0 ? 'text-[#00a800]' : 'text-gray-800';

                    return (
                      <tr key={stock.id} className="border-b border-gray-100 hover:bg-gray-50/50 transition-colors">
                        <td className="py-3 text-gray-600">{stock.code}</td>
                        <td className="py-3 font-bold text-[#e60012]">{stock.name}</td>
                        <td className={`py-3 font-bold ${colorClass}`}>{currentPrice > 0 ? currentPrice.toFixed(2) : '0.00'}</td>
                        <td className="py-3">
                          <span className={`px-2 py-0.5 rounded text-xs font-bold ${bgClass}`}>
                            {changePercent > 0 ? '+' : ''}{(changePercent * 100).toFixed(2)}%
                          </span>
                        </td>
                        <td className="py-3 text-gray-600">{stock.cost_price.toFixed(2)}</td>
                        <td className={`py-3 font-bold ${pnlColor}`}>
                          {pnl > 0 ? '+' : ''}{pnl.toFixed(2)}
                        </td>
                        <td className="py-3">
                          <div className="flex items-center justify-center gap-2">
                            <button 
                              onClick={() => startConsultation(stock)}
                              className="text-[#e60012] hover:bg-red-50 px-2 py-1 rounded text-xs font-medium border border-[#e60012] transition-colors flex items-center gap-1"
                            >
                              <Activity className="w-3 h-3" /> AI会诊
                            </button>
                            <button 
                              onClick={() => handleDelete(stock.id)}
                              className="text-gray-400 hover:text-red-500 text-xs"
                            >
                              删除
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                  {portfolio.length === 0 && (
                    <tr>
                      <td colSpan={7} className="py-12 text-gray-400">暂无自选股，请在上方添加</td>
                    </tr>
                  )}
                </tbody>
              </table>
            ) : (
              <div className="p-4">
                <div className="bg-blue-50 border border-blue-100 rounded p-3 mb-4 flex items-start gap-2 text-sm text-blue-800">
                  <ShieldCheck className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold mb-1">AI 预测回测系统</p>
                    <p className="text-blue-600/80">系统每 10 秒自动获取最新股价，并与 AI 历史预测进行对比。如果预测方向正确则标记为「神预测」，否则标记为「打脸」。</p>
                  </div>
                </div>
                
                <div className="grid gap-4">
                  {predictions.map(pred => {
                    const isSuccess = pred.status === 'success';
                    const isFailed = pred.status === 'failed';
                    const isPending = pred.status === 'pending';
                    
                    return (
                      <div key={pred.id} className="border border-gray-200 rounded-lg p-4 bg-white shadow-sm flex flex-col gap-3">
                        <div className="flex justify-between items-center border-b border-gray-100 pb-2">
                          <div className="flex items-center gap-3">
                            <span className="font-bold text-lg text-gray-800">{pred.name}</span>
                            <span className="text-xs text-gray-400 font-mono">{pred.code}</span>
                            <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">
                              {new Date(pred.predicted_at).toLocaleString()}
                            </span>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            {isPending && <span className="text-xs font-bold text-yellow-600 bg-yellow-50 border border-yellow-200 px-2 py-1 rounded">验证中...</span>}
                            {isSuccess && <span className="text-xs font-bold text-red-600 bg-red-50 border border-red-200 px-2 py-1 rounded flex items-center gap-1">🎯 神预测</span>}
                            {isFailed && <span className="text-xs font-bold text-green-600 bg-green-50 border border-green-200 px-2 py-1 rounded flex items-center gap-1">💥 被打脸</span>}
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div className="bg-gray-50 p-2 rounded border border-gray-100">
                            <div className="text-gray-500 text-xs mb-1">预测时价格</div>
                            <div className="font-mono font-bold">{pred.price_at_prediction.toFixed(2)}</div>
                          </div>
                          <div className="bg-gray-50 p-2 rounded border border-gray-100">
                            <div className="text-gray-500 text-xs mb-1">AI 建议</div>
                            <div className={`font-bold ${pred.recommendation.includes('涨') ? 'text-[#e60012]' : pred.recommendation.includes('跌') ? 'text-[#00a800]' : 'text-gray-700'}`}>
                              {pred.recommendation} {pred.target_price ? `(目标: ${pred.target_price})` : ''}
                            </div>
                          </div>
                          <div className="bg-gray-50 p-2 rounded border border-gray-100">
                            <div className="text-gray-500 text-xs mb-1">当前/验证价格</div>
                            <div className="font-mono font-bold">
                              {pred.actual_price ? pred.actual_price.toFixed(2) : '--'}
                            </div>
                          </div>
                        </div>
                        
                        <div className="text-sm text-gray-600 bg-gray-50/50 p-3 rounded border border-gray-100 mt-1">
                          <div className="font-bold text-gray-700 mb-1 text-xs">首席风控官总结：</div>
                          <div className="line-clamp-2 hover:line-clamp-none transition-all cursor-pointer">
                            {pred.chief_summary.replace(/\{.*\}/s, '')}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                  {predictions.length === 0 && (
                    <div className="text-center py-12 text-gray-400">
                      <ShieldCheck className="w-12 h-12 mx-auto mb-3 opacity-20" />
                      <p>暂无预测记录，请先在自选股池中发起 AI 会诊</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column */}
        <div className="bg-white shadow-sm border border-gray-200 rounded-sm h-full flex flex-col">
          <div className="flex border-b border-gray-200 bg-[#f8f9fa]">
            <button className="px-5 py-3.5 text-[#e60012] font-bold text-[15px] relative bg-white">
              快讯 <span className="text-xs italic font-normal ml-0.5 text-[#e60012]">7x24</span>
              <div className="absolute top-0 left-0 w-full h-[3px] bg-[#e60012]"></div>
            </button>
            <button className="px-5 py-3.5 text-gray-600 font-bold text-[15px] hover:text-[#e60012] transition-colors">
              AI 胜率战报
            </button>
          </div>
          
          <div className="p-5 flex-1">
            <h3 className="text-[13px] font-bold text-gray-500 mb-4">模型推演胜率追踪阵列</h3>
            <div className="space-y-2.5">
              {[
                { rank: 1, name: 'SiliconFlow', rate: '68.5%' },
                { rank: 2, name: 'Grok-Beta', rate: '62.3%' },
                { rank: 3, name: 'Gemini-1.5', rate: '55%' },
              ].map(model => (
                <div key={model.name} className="flex items-center justify-between border border-gray-100 p-2.5 rounded shadow-sm hover:border-gray-200 transition-colors">
                  <div className="flex items-center gap-3">
                    <span className="text-gray-400 font-mono text-xs bg-gray-50 px-2 py-0.5 rounded border border-gray-100">
                      {model.rank}
                    </span>
                    <span className="font-bold text-[14px] text-gray-800">{model.name}</span>
                  </div>
                  <span className="text-[#e60012] font-bold text-[14px]">{model.rate}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        
      </main>

      {/* Consultation Modal */}
      {consultingStock && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
          <div className="bg-[#f5f6f8] w-full max-w-6xl h-[90vh] rounded-xl shadow-2xl flex flex-col overflow-hidden border border-gray-200">
            {/* Header */}
            <div className="bg-white px-6 py-4 border-b border-gray-200 flex justify-between items-center shrink-0">
              <div className="flex items-center gap-3">
                <div className="bg-red-100 p-2 rounded-lg">
                  <Spade className="w-6 h-6 text-[#e60012]" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                    {consultingStock.name} <span className="text-gray-500 font-mono text-sm">({consultingStock.code})</span>
                  </h2>
                  <p className="text-sm text-gray-500">多智能体联合会诊报告</p>
                </div>
              </div>
              <button 
                onClick={() => setConsultingStock(null)}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-500"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Chief Summary */}
              <div className="bg-white rounded-xl shadow-sm border border-red-100 overflow-hidden">
                <div className="bg-gradient-to-r from-red-50 to-white px-5 py-3 border-b border-red-100 flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-[#e60012]" />
                  <h3 className="font-bold text-gray-800">首席风控官总结</h3>
                  {isConsulting && !streams.chief && <Loader2 className="w-4 h-4 text-[#e60012] animate-spin ml-2" />}
                </div>
                <div className="p-5 min-h-[120px] text-gray-700 leading-relaxed prose prose-sm max-w-none">
                  {streams.chief ? (
                    <Markdown>{streams.chief}</Markdown>
                  ) : (
                    <div className="flex items-center justify-center h-full text-gray-400 italic text-sm">
                      {isConsulting ? '等待各分析师提交报告，首席风控官正在汇总...' : '暂无总结'}
                    </div>
                  )}
                </div>
              </div>

              {/* 3 Agents Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Tech */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden flex flex-col h-[400px]">
                  <div className="bg-gray-50 px-4 py-3 border-b border-gray-200 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-blue-600" />
                      <h3 className="font-bold text-gray-700 text-sm">技术面分析师</h3>
                    </div>
                    {isConsulting && !streams.chief && <Loader2 className="w-3.5 h-3.5 text-blue-600 animate-spin" />}
                  </div>
                  <div className="p-4 flex-1 overflow-y-auto text-sm text-gray-600 leading-relaxed prose prose-sm max-w-none">
                    {streams.tech ? <Markdown>{streams.tech}</Markdown> : <span className="text-gray-400 italic">分析中...</span>}
                  </div>
                </div>

                {/* Fund */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden flex flex-col h-[400px]">
                  <div className="bg-gray-50 px-4 py-3 border-b border-gray-200 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Building className="w-4 h-4 text-emerald-600" />
                      <h3 className="font-bold text-gray-700 text-sm">基本面分析师</h3>
                    </div>
                    {isConsulting && !streams.chief && <Loader2 className="w-3.5 h-3.5 text-emerald-600 animate-spin" />}
                  </div>
                  <div className="p-4 flex-1 overflow-y-auto text-sm text-gray-600 leading-relaxed prose prose-sm max-w-none">
                    {streams.fund ? <Markdown>{streams.fund}</Markdown> : <span className="text-gray-400 italic">分析中...</span>}
                  </div>
                </div>

                {/* Sent */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden flex flex-col h-[400px]">
                  <div className="bg-gray-50 px-4 py-3 border-b border-gray-200 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-purple-600" />
                      <h3 className="font-bold text-gray-700 text-sm">情绪面分析师</h3>
                    </div>
                    {isConsulting && !streams.chief && <Loader2 className="w-3.5 h-3.5 text-purple-600 animate-spin" />}
                  </div>
                  <div className="p-4 flex-1 overflow-y-auto text-sm text-gray-600 leading-relaxed prose prose-sm max-w-none">
                    {streams.sent ? <Markdown>{streams.sent}</Markdown> : <span className="text-gray-400 italic">分析中...</span>}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
