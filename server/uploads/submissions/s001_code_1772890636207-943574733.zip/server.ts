import 'dotenv/config';
import express from 'express';
import { createServer as createViteServer } from 'vite';
import Database from 'better-sqlite3';
import YahooFinance from 'yahoo-finance2';
import { GoogleGenAI } from '@google/genai';

const yahooFinance = new YahooFinance();
const db = new Database('portfolio.db');

// Initialize DB
db.exec(`
  CREATE TABLE IF NOT EXISTS stocks_portfolio (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    cost_price REAL NOT NULL,
    quantity INTEGER NOT NULL,
    is_watched INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  
  CREATE TABLE IF NOT EXISTS predictions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    predicted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    price_at_prediction REAL NOT NULL,
    recommendation TEXT NOT NULL,
    target_price REAL,
    chief_summary TEXT,
    status TEXT DEFAULT 'pending',
    check_date DATETIME,
    actual_price REAL
  );
`);

const app = express();
app.use(express.json());

function formatTicker(code: string) {
  const lower = code.toLowerCase();
  if (lower.startsWith('sh')) return code.substring(2) + '.SS';
  if (lower.startsWith('sz')) return code.substring(2) + '.SZ';
  if (lower.startsWith('hk')) return code.substring(2) + '.HK';
  return code;
}

// API Routes
app.get('/api/v1/stock/:code/realtime', async (req, res) => {
  try {
    const { code } = req.params;
    const ticker = formatTicker(code);
    const quote = await yahooFinance.quote(ticker) as any;
    
    if (!quote || typeof quote.regularMarketPrice === 'undefined') {
      return res.status(404).json({ error: 'Stock not found or price unavailable' });
    }

    res.json({
      code,
      price: quote.regularMarketPrice,
      change: quote.regularMarketChange || 0,
      changePercent: quote.regularMarketChangePercent || 0,
      name: quote.shortName || quote.longName || code,
    });
  } catch (error) {
    console.error('Error fetching stock:', error);
    res.status(500).json({ error: 'Failed to fetch stock data' });
  }
});

app.get('/api/v1/portfolio', (req, res) => {
  try {
    const stmt = db.prepare('SELECT * FROM stocks_portfolio ORDER BY created_at DESC');
    const portfolio = stmt.all();
    res.json(portfolio);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch portfolio' });
  }
});

app.post('/api/v1/portfolio/add', (req, res) => {
  try {
    const { code, name, cost_price, quantity } = req.body;
    const stmt = db.prepare('INSERT INTO stocks_portfolio (code, name, cost_price, quantity) VALUES (?, ?, ?, ?)');
    const info = stmt.run(code, name || code, cost_price || 0, quantity || 0);
    res.json({ id: info.lastInsertRowid, success: true });
  } catch (error) {
    res.status(500).json({ error: 'Failed to add to portfolio' });
  }
});

app.delete('/api/v1/portfolio/:id', (req, res) => {
  try {
    const { id } = req.params;
    const stmt = db.prepare('DELETE FROM stocks_portfolio WHERE id = ?');
    stmt.run(id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete from portfolio' });
  }
});

// Predictions API
app.post('/api/v1/predictions', (req, res) => {
  try {
    const { code, name, price_at_prediction, recommendation, target_price, chief_summary } = req.body;
    const stmt = db.prepare(`
      INSERT INTO predictions (code, name, price_at_prediction, recommendation, target_price, chief_summary) 
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    const info = stmt.run(code, name, price_at_prediction, recommendation, target_price, chief_summary);
    res.json({ id: info.lastInsertRowid, success: true });
  } catch (error) {
    console.error('Failed to save prediction:', error);
    res.status(500).json({ error: 'Failed to save prediction' });
  }
});

app.get('/api/v1/predictions', (req, res) => {
  try {
    const stmt = db.prepare('SELECT * FROM predictions ORDER BY predicted_at DESC');
    const predictions = stmt.all();
    res.json(predictions);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch predictions' });
  }
});

app.post('/api/v1/predictions/verify', async (req, res) => {
  try {
    const stmt = db.prepare('SELECT * FROM predictions WHERE status = ?');
    const pendingPredictions = stmt.all('pending') as any[];
    
    let verifiedCount = 0;
    for (const pred of pendingPredictions) {
      try {
        const ticker = formatTicker(pred.code);
        const quote = await yahooFinance.quote(ticker) as any;
        if (quote && typeof quote.regularMarketPrice !== 'undefined') {
          const actualPrice = quote.regularMarketPrice;
          let status = 'pending';
          
          // Simple logic: if recommendation is '看涨' (Bullish), and actual > predicted -> success
          // If '看跌' (Bearish), and actual < predicted -> success
          if (pred.recommendation.includes('涨')) {
            status = actualPrice > pred.price_at_prediction ? 'success' : 'failed';
          } else if (pred.recommendation.includes('跌')) {
            status = actualPrice < pred.price_at_prediction ? 'success' : 'failed';
          } else {
            // For '持有' (Hold) or others, maybe check if it's within a range, but for now just mark as 'success' if it didn't drop much
            status = actualPrice >= pred.price_at_prediction * 0.95 ? 'success' : 'failed';
          }

          const updateStmt = db.prepare(`
            UPDATE predictions 
            SET status = ?, actual_price = ?, check_date = CURRENT_TIMESTAMP 
            WHERE id = ?
          `);
          updateStmt.run(status, actualPrice, pred.id);
          verifiedCount++;
        }
      } catch (err) {
        console.error(`Error verifying prediction for ${pred.code}:`, err);
      }
    }
    
    res.json({ success: true, verifiedCount });
  } catch (error) {
    console.error('Failed to verify predictions:', error);
    res.status(500).json({ error: 'Failed to verify predictions' });
  }
});

// Vite middleware
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
  }

  const PORT = 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
