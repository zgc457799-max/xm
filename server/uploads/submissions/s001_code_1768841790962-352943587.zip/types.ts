
export enum UserRole {
  STUDENT = 'STUDENT',
  TEACHER = 'TEACHER',
  ADMIN = 'ADMIN'
}

export interface User {
  id: string;
  name: string;
  role: UserRole;
  avatar?: string;
  stats?: {
    solved: number;
    rank: number;
    accuracy: number;
  };
}

export enum Difficulty {
  EASY = 'Easy',
  MEDIUM = 'Medium',
  HARD = 'Hard'
}

export interface Problem {
  id: string;
  title: string;
  difficulty: Difficulty;
  description: string; // Markdown
  tags: string[];
  passRate: number;
  inputExample?: string;
  outputExample?: string;
}

export interface Contest {
  id: string;
  title: string;
  startTime: string; // ISO date
  endTime: string; // ISO date
  status: 'UPCOMING' | 'LIVE' | 'ENDED';
  participantCount: number;
  isRegistered: boolean; // Current user registration status
  isLeaderboardOpen: boolean; // Teacher authorization for leaderboard
  description?: string;
}

export interface AiAnalysisResult {
  type: 'concept' | 'hint' | 'flowchart';
  content: string;
}
