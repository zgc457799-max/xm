import { GoogleGenAI, Type } from "@google/genai";

// Ensure API Key is available
const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// Models
const TEXT_MODEL = 'gemini-3-flash-preview';

/**
 * Student: Analyze the coding problem to explain key concepts.
 */
export const analyzeProblemConcepts = async (problemDescription: string): Promise<string> => {
  try {
    const prompt = `
      你是一位专业的计算机科学导师。
      请分析以下编程题目的描述，并识别出解决该问题所需的关键算法、数据结构和核心概念。
      **不要**直接提供代码解决方案。保持解释简洁明了。
      
      题目: ${problemDescription}
    `;

    const response = await ai.models.generateContent({
      model: TEXT_MODEL,
      contents: prompt,
      config: {
        systemInstruction: "你是一位帮助学生学习编程的耐心导师。"
      }
    });

    return response.text || "暂时无法分析该题目。";
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return "AI 服务当前不可用，请检查您的网络或 API Key。";
  }
};

/**
 * Student: Provide a hint or pseudocode logic.
 */
export const getProblemHint = async (problemDescription: string, currentCode: string): Promise<string> => {
  try {
    const prompt = `
      学生在解决这个问题时卡住了。请提供一个逻辑提示或伪代码思路来帮助他们继续。
      **不要**直接编写完整的 C/Python 代码。重点在于解题逻辑流。
      请用中文回答。

      题目: ${problemDescription}
      学生当前代码: ${currentCode}
    `;

    const response = await ai.models.generateContent({
      model: TEXT_MODEL,
      contents: prompt,
    });

    return response.text || "没有可用的提示。";
  } catch (error) {
    console.error("Gemini Hint Error:", error);
    return "AI 服务不可用。";
  }
};

/**
 * Student: Generate Mermaid.js flowchart code for the logic.
 */
export const generateLogicFlowchart = async (problemDescription: string): Promise<string> => {
  try {
    const prompt = `
      生成一个 Mermaid.js 流程图语法 (graph TD) 来表示解决此问题的逻辑。
      只返回 mermaid 代码块。节点标签请尽量使用中文简述。
      不要使用 markdown 反引号。

      题目: ${problemDescription}
    `;

    const response = await ai.models.generateContent({
      model: TEXT_MODEL,
      contents: prompt,
    });

    let text = response.text || "";
    // Cleanup simple markdown if present
    text = text.replace(/```mermaid/g, '').replace(/```/g, '').trim();
    return text;
  } catch (error) {
    console.error("Gemini Flowchart Error:", error);
    return "graph TD;\nA[生成流程图失败] --> B[请重试];";
  }
};

/**
 * Teacher: Parse raw text (from Word/PDF copy-paste) into structured Problem JSON.
 */
export const smartParseProblem = async (rawText: string): Promise<any> => {
  try {
    const response = await ai.models.generateContent({
      model: TEXT_MODEL,
      contents: `从以下文本中提取编程题目详情。请保留中文描述。`,
      config: {
        systemInstruction: "你是一个自动化数据录入助手。请将文本解析为结构化的 JSON 格式。",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING, description: "完整的题目描述，使用 Markdown 格式" },
            difficulty: { type: Type.STRING, enum: ["Easy", "Medium", "Hard"] },
            inputExample: { type: Type.STRING },
            outputExample: { type: Type.STRING },
            tags: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["title", "description", "difficulty"]
        }
      }
    });
    
    // The response is already validated JSON string due to responseMimeType
    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Gemini Smart Parse Error:", error);
    throw new Error("解析题目失败");
  }
};