
import React, { useState, useEffect, useRef } from 'react';
import { 
  Layout, BookOpen, Code, Award, User as UserIcon, 
  LogOut, ChevronRight, Play, CheckCircle, AlertCircle, 
  Brain, FileText, Zap, Upload, Plus, Users, BarChart2,
  Menu, X, Home, Book, Layers, ArrowLeft, Clock, Calendar, Trophy,
  Lock, Timer, ChevronLeft, ChevronRight as ChevronRightIcon,
  Trash2, Key, Settings, Search, FileSpreadsheet, Edit3, Save, Trash
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { UserRole, User, Problem, Difficulty, Contest } from './types';
import * as GeminiService from './services/geminiService';

// --- MOCK DATA (CHINESE) ---

const MOCK_USER_STUDENT: User = {
  id: 's123',
  name: '李明',
  role: UserRole.STUDENT,
  stats: { solved: 42, rank: 15, accuracy: 88 }
};

const MOCK_USER_TEACHER: User = {
  id: 't999',
  name: '张教授',
  role: UserRole.TEACHER
};

// Mock Problem Banks
const MOCK_BANKS = [
  { id: 'b1', title: '蓝桥杯省赛真题库', count: 124, description: '历年蓝桥杯C/C++组省赛真题合集' },
  { id: 'b2', title: 'C语言入门 100 题', count: 100, description: '适合编程新手的语法基础训练' },
  { id: 'b3', title: '数据结构专项训练', count: 85, description: '链表、树、图论等核心数据结构' },
  { id: 'b4', title: 'LeetCode 热题 HOT100', count: 100, description: '大厂面试高频算法题' },
  { id: 'b5', title: '动态规划精选', count: 45, description: '背包问题、状态转移方程专项' },
  { id: 'b6', title: '计算机考研复试机试', count: 60, description: '各大高校复试真题' },
  { id: 'b7', title: 'Python 趣味编程', count: 30, description: '寓教于乐的小游戏开发' },
  { id: 'b8', title: 'ACM 竞赛入门', count: 150, description: 'ICPC/CCPC 基础算法模板题' },
];

// Mock Problems
const MOCK_PROBLEMS: Problem[] = [
  {
    id: '1001',
    title: '两数之和 (Two Sum)',
    difficulty: Difficulty.EASY,
    passRate: 78.5,
    tags: ['数组', '哈希表'],
    description: '给定一个整数数组 `nums` 和一个整数目标值 `target`，请你在该数组中找出 **和为目标值** `target` 的那 **两个** 整数，并返回它们的数组下标。\n\n你可以假设每种输入只会对应一个答案。但是，数组中同一个元素在答案里不能重复出现。',
    inputExample: 'nums = [2,7,11,15], target = 9',
    outputExample: '[0,1]'
  },
  {
    id: '1002',
    title: '最长回文子串',
    difficulty: Difficulty.MEDIUM,
    passRate: 45.2,
    tags: ['字符串', '动态规划'],
    description: '给你一个字符串 `s`，找到 `s` 中最长的回文子串。\n\n如果字符串的反序与原始字符串相同，则该字符串称为回文字符串。',
    inputExample: 's = "babad"',
    outputExample: '"bab"'
  },
  {
    id: '1003',
    title: '合并两个有序链表',
    difficulty: Difficulty.EASY,
    passRate: 82.1,
    tags: ['链表', '递归'],
    description: '将两个升序链表合并为一个新的 **升序** 链表并返回。新链表是通过拼接给定的两个链表的所有节点组成的。',
    inputExample: 'l1 = [1,2,4], l2 = [1,3,4]',
    outputExample: '[1,1,2,3,4,4]'
  },
  {
    id: '1004',
    title: '接雨水',
    difficulty: Difficulty.HARD,
    passRate: 32.5,
    tags: ['栈', '数组', '双指针'],
    description: '给定 `n` 个非负整数表示每个宽度为 1 的柱子的高度图，计算按此排列的柱子，下雨之后能接多少雨水。',
    inputExample: 'height = [0,1,0,2,1,0,1,3,2,1,2,1]',
    outputExample: '6'
  }
];

// Mock Students for Teacher View
const MOCK_STUDENTS_LIST = [
  { id: 's123', name: '李明', class: '计算机2301', solved: 42, accuracy: '88%' },
  { id: 's124', name: '王晓红', class: '计算机2301', solved: 38, accuracy: '85%' },
  { id: 's125', name: '赵强', class: '计算机2302', solved: 56, accuracy: '92%' },
  { id: 's126', name: '张伟', class: '软件2301', solved: 12, accuracy: '60%' },
  { id: 's127', name: '陈娜', class: '软件2301', solved: 25, accuracy: '75%' },
];

const NOW = Date.now();
// Initial Contests State
const INITIAL_CONTESTS: Contest[] = [
  {
    id: 'c1',
    title: '传智杯校内选拔赛',
    startTime: new Date(NOW - 3600 * 1000).toISOString(), 
    endTime: new Date(NOW + 3600 * 100